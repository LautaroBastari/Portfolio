export default function App() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center p-4">
      <h1 className="text-4xl font-bold text-white mb-4 animate-fade-in">
        ¡Hola, soy Lautaro!
      </h1>
      <p className="text-lg text-gray-300">
        Este es el inicio de mi portfolio con Tailwind + React.
      </p>
    </div>
  );
}
